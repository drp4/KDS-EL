"""
plot_all_figures.py
===================
Generates all publication figures for MEL-KGEF paper.
IEEE Transactions / Applied Soft Computing Q1 style.

Figures produced
----------------
Fig 1  — Classification accuracy comparison (3×3 grouped bar, all 9 methods)
Fig 2  — Number of selected features comparison (3×3 grouped bar)
Fig 3  — Ablation study: accuracy (grouped bar, 4 variants × 9 datasets)
Fig 4  — Ablation study: feature count (same layout)
Fig 5  — Stability boxplots (MEL_KGEF vs top-3 competitors, 3×3)
Fig 6  — Accuracy–feature trade-off scatter (bubble chart)
Fig 7  — Average Friedman rank bar chart (all 9 methods)
Fig 8  — NHD diversity comparison (MEL methods + PSO_CSM + IGPSO)
Fig 9  — Runtime comparison heatmap / bar
Fig 10 — Convergence curves (requires npy files — skipped if not found)

Usage
-----
python plot_all_figures.py
Outputs to ./figures/  (creates directory if absent)

npy layout expected (for Fig 10)
----------------------------------
curves_all_rerun_stratified/curve_{VERSION}_{DATASET}_run{N}.npy   — fitness curve
curves_all_rerun_stratified/nhd_{VERSION}_{DATASET}_run{N}.npy     — NHD curve (MEL methods)
IGPSO / PSO_CSM save only curve_*.npy (single npy per run).
"""

import os, warnings
import numpy as np
import pandas as pd
import matplotlib as mpl
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import matplotlib.ticker as mticker
from matplotlib.gridspec import GridSpec
from scipy import stats

warnings.filterwarnings("ignore")

# ── Paths ────────────────────────────────────────────────────────────────────
CSV_PATH   = "all_data.csv"        # 810 rows, 9 versions × 9 datasets × 10 runs
CURVES_DIR = "curves_all_rerun_stratified"
OUT_DIR    = "figures"
os.makedirs(OUT_DIR, exist_ok=True)

# ── Load data ─────────────────────────────────────────────────────────────────
df = pd.read_csv(CSV_PATH)

# ── Global constants ──────────────────────────────────────────────────────────
DATASETS   = ['Adenoma','ALL_AML','ALL3','ALL4','CNS','Colon','DLBCL','Lymphoma','Stroke']
DS_LABELS  = ['Adenoma','ALL-AML','ALL3','ALL4','CNS','Colon','DLBCL','Lymphoma','Stroke']

ALL_V      = ['BPSO','SaWDE','FWPSO','MEL','MEL_NHD','MEL_KGEF_noNHD','MEL_KGEF','PSO_CSM','IGPSO']
ABL_V      = ['MEL','MEL_NHD','MEL_KGEF_noNHD','MEL_KGEF']
ABL_LABELS = ['MEL','MEL+EMDO','MEL+KGEF','MEL-KGEF\n(Proposed)']

V_LABELS = {
    'BPSO': 'BPSO', 'SaWDE': 'SaWDE', 'FWPSO': 'FWPSO',
    'MEL': 'MEL', 'MEL_NHD': 'MEL+EMDO',
    'MEL_KGEF_noNHD': 'MEL+KGEF',
    'MEL_KGEF': 'MEL-KGEF', 'PSO_CSM': 'PSO-CSM', 'IGPSO': 'IGPSO',
}

# ── IEEE color palette (colorblind-safe, 9 distinct) ─────────────────────────
# Proposed method always gets the standout red-orange
COLORS = {
    'BPSO':            '#8c8c8c',
    'SaWDE':           '#b5b5b5',
    'FWPSO':           '#5b9bd5',
    'MEL':             '#4bacc6',
    'MEL_NHD':         '#70ad47',
    'MEL_KGEF_noNHD':  '#ffc000',
    'MEL_KGEF':        '#c00000',   # proposed — standout
    'PSO_CSM':         '#7030a0',
    'IGPSO':           '#ed7d31',
}

HATCHES = {
    'BPSO': '////',  'SaWDE': '\\\\\\\\', 'FWPSO': '----',
    'MEL': '....',   'MEL_NHD': 'xxxx',  'MEL_KGEF_noNHD': '++++',
    'MEL_KGEF': '',  'PSO_CSM': 'oooo',  'IGPSO': '****',
}

# ── IEEE rcParams ─────────────────────────────────────────────────────────────
IEEE = {
    'font.family':        'DejaVu Serif',
    'font.size':          8,
    'axes.titlesize':     8,
    'axes.labelsize':     8,
    'xtick.labelsize':    7,
    'ytick.labelsize':    7,
    'legend.fontsize':    6.5,
    'legend.framealpha':  0.9,
    'legend.edgecolor':   '0.7',
    'axes.linewidth':     0.7,
    'grid.linewidth':     0.4,
    'lines.linewidth':    1.0,
    'lines.markersize':   4,
    'patch.linewidth':    0.5,
    'xtick.major.width':  0.7,
    'ytick.major.width':  0.7,
    'xtick.major.size':   3,
    'ytick.major.size':   3,
    'axes.spines.top':    False,
    'axes.spines.right':  False,
    'figure.dpi':         300,
    'savefig.dpi':        300,
    'savefig.bbox':       'tight',
    'savefig.pad_inches': 0.02,
}
mpl.rcParams.update(IEEE)

# ── Helper functions ──────────────────────────────────────────────────────────
def get(v, ds, metric='Accuracy'):
    sub = df[(df['Version']==v) & (df['Dataset']==ds)][metric]
    return sub.values

def mean_std(v, ds, metric='Accuracy'):
    vals = get(v, ds, metric)
    return vals.mean(), vals.std()


def add_significance_bar(ax, x1, x2, y, p, h=0.005):
    """Add a significance bracket between two bars."""
    if p < 0.001: txt = '***'
    elif p < 0.01: txt = '**'
    elif p < 0.05: txt = '*'
    else: return
    ax.plot([x1, x1, x2, x2], [y, y+h, y+h, y], lw=0.8, c='k')
    ax.text((x1+x2)/2, y+h, txt, ha='center', va='bottom', fontsize=6)


def make_legend_handles(versions, labels=None):
    handles = []
    for v in versions:
        lbl = labels[versions.index(v)] if labels else V_LABELS.get(v, v)
        prop = dict(
            color=COLORS[v], hatch=HATCHES[v],
            edgecolor='k' if HATCHES[v] else COLORS[v],
            linewidth=0.4, label=lbl,
        )
        handles.append(mpatches.Patch(**prop))
    return handles


# ═════════════════════════════════════════════════════════════════════════════
# Fig 1 — Classification Accuracy (3×3, all 9 methods)
# ═════════════════════════════════════════════════════════════════════════════
def fig_accuracy():
    print("Generating Fig 1: Accuracy comparison...")
    fig, axes = plt.subplots(3, 3, figsize=(7.16, 5.2))
    axes = axes.ravel()

    n_v  = len(ALL_V)
    x    = np.arange(n_v)
    w    = 0.65

    for ax, ds, dslbl in zip(axes, DATASETS, DS_LABELS):
        means = [get(v, ds).mean() for v in ALL_V]
        stds  = [get(v, ds).std()  for v in ALL_V]
        bars = ax.bar(
            x, means, w,
            color   = [COLORS[v] for v in ALL_V],
            edgecolor = 'k',
            linewidth = 0.4,
            yerr    = stds,
            error_kw = dict(elinewidth=0.6, capsize=1.5, capthick=0.6, ecolor='0.3'),
        )
        # Hatch for proposed
        for bar, v in zip(bars, ALL_V):
            if HATCHES[v]:
                bar.set_hatch(HATCHES[v])

        # Highlight proposed (last bar logically at index 6 for MEL_KGEF)
        kgef_idx = ALL_V.index('MEL_KGEF')
        bars[kgef_idx].set_edgecolor('black')
        bars[kgef_idx].set_linewidth(1.0)

        ax.set_title(dslbl, fontsize=8, fontweight='normal', pad=2)
        ax.set_xticks(x)
        ax.set_xticklabels([V_LABELS[v] for v in ALL_V], rotation=45, ha='right', fontsize=6)
        ax.yaxis.set_major_formatter(mticker.FormatStrFormatter('%.2f'))
        ax.yaxis.set_major_locator(mticker.MaxNLocator(4, prune='lower'))
        ax.grid(axis='y', linestyle='--', alpha=0.5)

        # Dynamic y-axis: zoom in on the interesting region
        all_min = min(m - s for m, s in zip(means, stds))
        all_max = max(m + s for m, s in zip(means, stds))
        margin  = (all_max - all_min) * 0.15
        ax.set_ylim(max(0, all_min - margin - 0.01), min(1.0, all_max + margin + 0.01))

    # Shared legend
    handles = make_legend_handles(ALL_V)
    fig.legend(handles=handles, loc='lower center', ncol=5,
               bbox_to_anchor=(0.5, -0.04), frameon=True,
               columnspacing=0.8, handlelength=1.2, handleheight=0.9)
    fig.text(0.04, 0.5, 'Classification Accuracy', va='center',
             rotation='vertical', fontsize=8)
    fig.tight_layout(rect=[0.05, 0.07, 1, 1])
    path = os.path.join(OUT_DIR, 'fig1_accuracy.pdf')
    fig.savefig(path)
    fig.savefig(path.replace('.pdf','.png'))
    plt.close(fig)
    print(f"  Saved {path}")


# ═════════════════════════════════════════════════════════════════════════════
# Fig 2 — Number of Selected Features (3×3, all 9 methods, log scale)
# ═════════════════════════════════════════════════════════════════════════════
def fig_features():
    print("Generating Fig 2: Feature count comparison...")
    fig, axes = plt.subplots(3, 3, figsize=(7.16, 5.2))
    axes = axes.ravel()
    n_v = len(ALL_V)
    x   = np.arange(n_v)
    w   = 0.65

    for ax, ds, dslbl in zip(axes, DATASETS, DS_LABELS):
        means = [get(v, ds, 'Num_Features').mean() for v in ALL_V]
        stds  = [get(v, ds, 'Num_Features').std()  for v in ALL_V]
        bars = ax.bar(
            x, means, w,
            color=[COLORS[v] for v in ALL_V],
            edgecolor='k', linewidth=0.4,
            yerr=stds,
            error_kw=dict(elinewidth=0.6, capsize=1.5, capthick=0.6, ecolor='0.3'),
        )
        for bar, v in zip(bars, ALL_V):
            if HATCHES[v]: bar.set_hatch(HATCHES[v])
        kgef_idx = ALL_V.index('MEL_KGEF')
        bars[kgef_idx].set_edgecolor('black')
        bars[kgef_idx].set_linewidth(1.0)

        ax.set_title(dslbl, fontsize=8, pad=2)
        ax.set_xticks(x)
        ax.set_xticklabels([V_LABELS[v] for v in ALL_V], rotation=45, ha='right', fontsize=6)
        ax.set_yscale('log')
        ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda y, _: f'{int(y):,}'))
        ax.grid(axis='y', linestyle='--', alpha=0.5, which='both')

    handles = make_legend_handles(ALL_V)
    fig.legend(handles=handles, loc='lower center', ncol=5,
               bbox_to_anchor=(0.5, -0.04), frameon=True,
               columnspacing=0.8, handlelength=1.2, handleheight=0.9)
    fig.text(0.04, 0.5, 'Number of Selected Features (log)', va='center',
             rotation='vertical', fontsize=8)
    fig.tight_layout(rect=[0.05, 0.07, 1, 1])
    path = os.path.join(OUT_DIR, 'fig2_features.pdf')
    fig.savefig(path)
    fig.savefig(path.replace('.pdf','.png'))
    plt.close(fig)
    print(f"  Saved {path}")


# ═════════════════════════════════════════════════════════════════════════════
# Fig 3 — Ablation Study (accuracy + features, side by side)
# ═════════════════════════════════════════════════════════════════════════════
def fig_ablation():
    print("Generating Fig 3: Ablation study...")
    fig, axes = plt.subplots(1, 2, figsize=(7.16, 3.0))

    n_ds = len(DATASETS)
    x    = np.arange(n_ds)
    w_total = 0.7
    n_v     = len(ABL_V)
    w       = w_total / n_v
    offsets = np.linspace(-(n_v-1)/2*w, (n_v-1)/2*w, n_v)

    ABL_COLORS = [COLORS[v] for v in ABL_V]
    ABL_HATCH  = [HATCHES[v] for v in ABL_V]

    for ax_idx, (ax, metric, ylabel) in enumerate(zip(
        axes,
        ['Accuracy', 'Num_Features'],
        ['Classification Accuracy', 'Number of Selected Features'],
    )):
        for i, (v, off, col, htch, lbl) in enumerate(
            zip(ABL_V, offsets, ABL_COLORS, ABL_HATCH, ABL_LABELS)
        ):
            means = [get(v, ds, metric).mean() for ds in DATASETS]
            stds  = [get(v, ds, metric).std()  for ds in DATASETS]
            bars = ax.bar(
                x + off, means, w,
                color=col, edgecolor='k', linewidth=0.4,
                label=lbl,
                yerr=stds,
                error_kw=dict(elinewidth=0.5, capsize=1.2, capthick=0.5, ecolor='0.3'),
            )
            for bar in bars:
                if htch: bar.set_hatch(htch)

        ax.set_xticks(x)
        ax.set_xticklabels(DS_LABELS, rotation=40, ha='right', fontsize=7)
        ax.set_ylabel(ylabel, fontsize=8)
        ax.grid(axis='y', linestyle='--', alpha=0.5)
        if metric == 'Num_Features':
            ax.set_yscale('log')
            ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda y, _: f'{int(y):,}'))

        if ax_idx == 0:
            handles = make_legend_handles(ABL_V, ABL_LABELS)
            ax.legend(handles=handles, fontsize=7, ncol=2,
                      loc='lower right', frameon=True)

    fig.tight_layout(w_pad=2.5)
    path = os.path.join(OUT_DIR, 'fig3_ablation.pdf')
    fig.savefig(path)
    fig.savefig(path.replace('.pdf','.png'))
    plt.close(fig)
    print(f"  Saved {path}")


# ═════════════════════════════════════════════════════════════════════════════
# Fig 4 — Boxplot Stability (MEL_KGEF vs 3 competitors, accuracy)
# ═════════════════════════════════════════════════════════════════════════════
def fig_boxplot():
    print("Generating Fig 4: Stability boxplots...")
    BOX_V    = ['FWPSO', 'PSO_CSM', 'IGPSO', 'MEL_KGEF']
    BOX_LBLS = ['FWPSO', 'PSO-CSM', 'IGPSO', 'MEL-KGEF\n(Proposed)']
    BOX_COLS = [COLORS[v] for v in BOX_V]

    fig, axes = plt.subplots(3, 3, figsize=(7.16, 5.5))
    axes = axes.ravel()

    for ax, ds, dslbl in zip(axes, DATASETS, DS_LABELS):
        data_list = [get(v, ds) for v in BOX_V]
        bp = ax.boxplot(
            data_list,
            patch_artist=True,
            widths=0.55,
            medianprops=dict(color='black', linewidth=1.2),
            whiskerprops=dict(linewidth=0.7),
            capprops=dict(linewidth=0.7),
            flierprops=dict(marker='o', markersize=2, linewidth=0.5,
                            markeredgecolor='0.5', markerfacecolor='none'),
            boxprops=dict(linewidth=0.6),
        )
        for patch, col in zip(bp['boxes'], BOX_COLS):
            patch.set_facecolor(col)
            patch.set_alpha(0.75)

        # Significance: KGEF vs each
        kgef_data = get('MEL_KGEF', ds)
        ymax = max(np.concatenate(data_list))
        step = (ymax - min(np.concatenate(data_list))) * 0.04
        for ci, v in enumerate(BOX_V[:-1]):
            _, p = stats.wilcoxon(kgef_data, get(v, ds))
            if p < 0.05:
                y = ymax + step * (ci + 1)
                add_significance_bar(ax, ci + 1, len(BOX_V), y, p, h=step*0.3)

        ax.set_title(dslbl, fontsize=8, pad=2)
        ax.set_xticks(range(1, len(BOX_V)+1))
        ax.set_xticklabels(BOX_LBLS, fontsize=6.5)
        ax.yaxis.set_major_formatter(mticker.FormatStrFormatter('%.2f'))
        ax.yaxis.set_major_locator(mticker.MaxNLocator(4))
        ax.grid(axis='y', linestyle='--', alpha=0.5)

    fig.text(0.04, 0.5, 'Classification Accuracy', va='center',
             rotation='vertical', fontsize=8)
    fig.tight_layout(rect=[0.05, 0.0, 1, 1])
    path = os.path.join(OUT_DIR, 'fig4_boxplot.pdf')
    fig.savefig(path)
    fig.savefig(path.replace('.pdf','.png'))
    plt.close(fig)
    print(f"  Saved {path}")


# ═════════════════════════════════════════════════════════════════════════════
# Fig 5 — Accuracy–Feature Trade-off Scatter
# ═════════════════════════════════════════════════════════════════════════════
def fig_tradeoff():
    print("Generating Fig 5: Accuracy–feature trade-off scatter...")
    # Select 4 representative datasets + all for context
    fig, axes = plt.subplots(2, 3, figsize=(7.16, 4.2))
    axes = axes.ravel()

    SHOW_DS = DATASETS[:6]   # show 6 to fill 2×3 grid

    for ax, ds, dslbl in zip(axes, SHOW_DS, DS_LABELS[:6]):
        dim = df[df['Dataset']==ds]['Num_Features'].max() * 1.1 + 1  # total features
        for v in ALL_V:
            vals = df[(df['Version']==v) & (df['Dataset']==ds)]
            acc  = vals['Accuracy'].values
            nf   = vals['Num_Features'].values
            col  = COLORS[v]
            lw   = 1.5 if v == 'MEL_KGEF' else 0.8
            zord = 10 if v == 'MEL_KGEF' else 2
            ms   = 5  if v == 'MEL_KGEF' else 3
            mk   = '*' if v == 'MEL_KGEF' else 'o'
            ax.scatter(nf / dim * 100, acc * 100,
                       color=col, s=ms**2, zorder=zord,
                       marker=mk, linewidths=0,
                       label=V_LABELS[v], alpha=0.85)

        ax.set_title(dslbl, fontsize=8, pad=2)
        ax.set_xlabel('Feature ratio (%)', fontsize=7)
        ax.set_ylabel('Accuracy (%)', fontsize=7)
        ax.grid(linestyle='--', alpha=0.4)
        ax.xaxis.set_major_formatter(mticker.FormatStrFormatter('%.0f'))
        ax.yaxis.set_major_formatter(mticker.FormatStrFormatter('%.0f'))

    handles = make_legend_handles(ALL_V)
    fig.legend(handles=handles, loc='lower center', ncol=5,
               bbox_to_anchor=(0.5, -0.04), frameon=True,
               columnspacing=0.8, handlelength=1.0, handleheight=0.9)
    fig.tight_layout(rect=[0, 0.08, 1, 1])
    path = os.path.join(OUT_DIR, 'fig5_tradeoff.pdf')
    fig.savefig(path)
    fig.savefig(path.replace('.pdf','.png'))
    plt.close(fig)
    print(f"  Saved {path}")


# ═════════════════════════════════════════════════════════════════════════════
# Fig 6 — Average Rank + Friedman
# ═════════════════════════════════════════════════════════════════════════════
def fig_rank():
    print("Generating Fig 6: Average rank chart...")
    # Compute ranks
    rank_dict = {v: [] for v in ALL_V}
    for ds in DATASETS:
        means = {v: get(v, ds).mean() for v in ALL_V}
        for r, v in enumerate(sorted(means, key=means.get, reverse=True), 1):
            rank_dict[v].append(r)
    avg_ranks = {v: np.mean(rank_dict[v]) for v in ALL_V}
    rank_se   = {v: np.std(rank_dict[v]) / np.sqrt(len(DATASETS)) for v in ALL_V}

    sorted_v = sorted(avg_ranks, key=avg_ranks.get)
    fig, ax = plt.subplots(figsize=(3.5, 2.8))

    y = np.arange(len(sorted_v))
    values = [avg_ranks[v] for v in sorted_v]
    errors = [rank_se[v]   for v in sorted_v]
    colors = [COLORS[v]    for v in sorted_v]

    bars = ax.barh(y, values, 0.6, color=colors, edgecolor='k',
                   linewidth=0.4, xerr=errors,
                   error_kw=dict(elinewidth=0.6, capsize=2, capthick=0.6))
    for bar, v in zip(bars, sorted_v):
        if HATCHES[v]: bar.set_hatch(HATCHES[v])

    # Annotate proposed
    kgef_y = sorted_v.index('MEL_KGEF')
    ax.annotate('Proposed',
                xy=(avg_ranks['MEL_KGEF'], kgef_y),
                xytext=(avg_ranks['MEL_KGEF'] + 0.8, kgef_y),
                arrowprops=dict(arrowstyle='->', lw=0.8),
                fontsize=7, va='center')

    ax.set_yticks(y)
    ax.set_yticklabels([V_LABELS[v] for v in sorted_v], fontsize=7)
    ax.set_xlabel('Average Friedman Rank', fontsize=8)
    ax.set_xlim(0, max(values) + 1.5)
    ax.grid(axis='x', linestyle='--', alpha=0.5)
    ax.invert_yaxis()

    # Friedman stat
    matrix = np.array([[get(v, ds).mean() for v in ALL_V] for ds in DATASETS])
    chi2, p = stats.friedmanchisquare(*[matrix[:, i] for i in range(len(ALL_V))])
    ax.set_title(f'Friedman: χ²={chi2:.2f}, p={p:.2e}', fontsize=7, pad=3)

    fig.tight_layout()
    path = os.path.join(OUT_DIR, 'fig6_rank.pdf')
    fig.savefig(path)
    fig.savefig(path.replace('.pdf','.png'))
    plt.close(fig)
    print(f"  Saved {path}")


# ═════════════════════════════════════════════════════════════════════════════
# Fig 7 — NHD Diversity Comparison (bar chart, 4 methods with NHD data)
# ═════════════════════════════════════════════════════════════════════════════
def fig_nhd():
    print("Generating Fig 7: NHD diversity comparison...")
    NHD_V    = ['MEL_NHD', 'MEL_KGEF_noNHD', 'MEL_KGEF', 'PSO_CSM', 'IGPSO']
    # MEL_KGEF_noNHD has NHD=0 in CSV; handle gracefully
    NHD_LBLS = ['MEL+EMDO', 'MEL+KGEF', 'MEL-KGEF\n(Proposed)', 'PSO-CSM', 'IGPSO']
    has_nhd  = ['MEL_NHD', 'MEL_KGEF', 'PSO_CSM', 'IGPSO']

    fig, ax = plt.subplots(figsize=(7.16, 2.6))
    n_ds = len(DATASETS)
    n_v  = len(has_nhd)
    w    = 0.7 / n_v
    offsets = np.linspace(-(n_v-1)/2*w, (n_v-1)/2*w, n_v)
    x    = np.arange(n_ds)

    for v, off in zip(has_nhd, offsets):
        means = [get(v, ds, 'Avg_NHD').mean() for ds in DATASETS]
        stds  = [get(v, ds, 'Avg_NHD').std()  for ds in DATASETS]
        bars  = ax.bar(x + off, means, w,
                       color=COLORS[v], edgecolor='k', linewidth=0.4,
                       label=V_LABELS[v],
                       yerr=stds,
                       error_kw=dict(elinewidth=0.5, capsize=1.2, capthick=0.5))
        for bar in bars:
            if HATCHES[v]: bar.set_hatch(HATCHES[v])

    ax.set_xticks(x)
    ax.set_xticklabels(DS_LABELS, fontsize=7)
    ax.set_ylabel('Mean Population NHD', fontsize=8)
    ax.set_ylim(0, 1.0)
    ax.grid(axis='y', linestyle='--', alpha=0.5)
    handles = make_legend_handles(has_nhd)
    ax.legend(handles=handles, ncol=4, fontsize=7,
              loc='upper right', frameon=True)

    fig.tight_layout()
    path = os.path.join(OUT_DIR, 'fig7_nhd.pdf')
    fig.savefig(path)
    fig.savefig(path.replace('.pdf','.png'))
    plt.close(fig)
    print(f"  Saved {path}")


# ═════════════════════════════════════════════════════════════════════════════
# Fig 8 — Runtime Comparison (grouped bar + log scale)
# ═════════════════════════════════════════════════════════════════════════════
def fig_runtime():
    print("Generating Fig 8: Runtime comparison...")
    RT_V    = ['BPSO','SaWDE','FWPSO','MEL','PSO_CSM','IGPSO','MEL_KGEF']
    RT_LBLS = [V_LABELS[v] for v in RT_V]

    fig, ax = plt.subplots(figsize=(7.16, 2.6))
    n_ds = len(DATASETS)
    n_v  = len(RT_V)
    w    = 0.7 / n_v
    offsets = np.linspace(-(n_v-1)/2*w, (n_v-1)/2*w, n_v)
    x    = np.arange(n_ds)

    for v, off in zip(RT_V, offsets):
        means = [get(v, ds, 'Time_sec').mean() for ds in DATASETS]
        bars  = ax.bar(x + off, means, w,
                       color=COLORS[v], edgecolor='k', linewidth=0.4,
                       label=V_LABELS[v])
        for bar in bars:
            if HATCHES[v]: bar.set_hatch(HATCHES[v])

    ax.set_xticks(x)
    ax.set_xticklabels(DS_LABELS, fontsize=7)
    ax.set_ylabel('Avg. Runtime (s, log)', fontsize=8)
    ax.set_yscale('log')
    ax.yaxis.set_major_formatter(mticker.FuncFormatter(
        lambda y, _: f'{int(y):,}' if y >= 10 else f'{y:.1f}'
    ))
    ax.grid(axis='y', linestyle='--', alpha=0.5, which='both')
    handles = make_legend_handles(RT_V)
    ax.legend(handles=handles, ncol=4, fontsize=6.5,
              loc='upper left', frameon=True)

    fig.tight_layout()
    path = os.path.join(OUT_DIR, 'fig8_runtime.pdf')
    fig.savefig(path)
    fig.savefig(path.replace('.pdf','.png'))
    plt.close(fig)
    print(f"  Saved {path}")


# ═════════════════════════════════════════════════════════════════════════════
# Fig 9 — Wilcoxon significance heatmap
# ═════════════════════════════════════════════════════════════════════════════
def fig_wilcoxon_heatmap():
    print("Generating Fig 9: Wilcoxon significance heatmap...")
    COMP_V  = ['BPSO','SaWDE','FWPSO','MEL','MEL_NHD','MEL_KGEF_noNHD','PSO_CSM','IGPSO']
    COMP_LB = ['BPSO','SaWDE','FWPSO','MEL','MEL+EMDO','MEL+KGEF','PSO-CSM','IGPSO']

    # pval matrix: rows=datasets, cols=competitors
    pmat   = np.zeros((len(DATASETS), len(COMP_V)))
    dmat   = np.zeros_like(pmat)   # sign: +1 KGEF wins, -1 KGEF loses
    for i, ds in enumerate(DATASETS):
        a = get('MEL_KGEF', ds)
        for j, v in enumerate(COMP_V):
            b = get(v, ds)
            n = min(len(a), len(b))
            try:
                _, p = stats.wilcoxon(a[:n], b[:n])
            except:
                p = 1.0
            pmat[i, j] = p
            dmat[i, j] = 1 if a.mean() > b.mean() else -1

    # Color: green=KGEF wins, red=KGEF loses; darkness=significance
    fig, ax = plt.subplots(figsize=(5.5, 3.2))

    cmap_win  = plt.cm.Greens
    cmap_lose = plt.cm.Reds

    img_data = np.zeros((*pmat.shape, 4))
    for i in range(pmat.shape[0]):
        for j in range(pmat.shape[1]):
            p = pmat[i, j]
            sig = 0.85 if p < 0.001 else 0.65 if p < 0.01 else 0.45 if p < 0.05 else 0.18
            if dmat[i, j] > 0:
                img_data[i, j] = cmap_win(sig)
            else:
                img_data[i, j] = cmap_lose(sig)

    ax.imshow(img_data, aspect='auto')

    # Annotations
    for i in range(pmat.shape[0]):
        for j in range(pmat.shape[1]):
            p = pmat[i, j]
            txt = '***' if p < 0.001 else '**' if p < 0.01 else '*' if p < 0.05 else 'ns'
            ax.text(j, i, txt, ha='center', va='center', fontsize=7,
                    color='white' if p < 0.05 else '0.5', fontweight='bold' if p<0.05 else 'normal')

    ax.set_xticks(range(len(COMP_V)))
    ax.set_xticklabels(COMP_LB, rotation=35, ha='right', fontsize=7)
    ax.set_yticks(range(len(DATASETS)))
    ax.set_yticklabels(DS_LABELS, fontsize=7)
    ax.set_title('MEL-KGEF vs. Competitors — Wilcoxon Signed-Rank Test', fontsize=8, pad=4)

    # Legend patches
    from matplotlib.patches import Patch
    legend_elems = [
        Patch(facecolor=cmap_win(0.85),  label='Win (p<0.001)'),
        Patch(facecolor=cmap_win(0.65),  label='Win (p<0.01)'),
        Patch(facecolor=cmap_win(0.45),  label='Win (p<0.05)'),
        Patch(facecolor=cmap_win(0.18),  label='Win (ns)'),
        Patch(facecolor=cmap_lose(0.45), label='Loss (p<0.05)'),
        Patch(facecolor=cmap_lose(0.18), label='Loss (ns)'),
    ]
    ax.legend(handles=legend_elems, loc='lower center',
              bbox_to_anchor=(0.5, -0.42), ncol=3, fontsize=6.5, frameon=True)

    fig.tight_layout(rect=[0, 0.12, 1, 1])
    path = os.path.join(OUT_DIR, 'fig9_wilcoxon.pdf')
    fig.savefig(path)
    fig.savefig(path.replace('.pdf','.png'))
    plt.close(fig)
    print(f"  Saved {path}")


# ═════════════════════════════════════════════════════════════════════════════
# Fig 10 — Convergence Curves (from npy files)
# ═════════════════════════════════════════════════════════════════════════════
def fig_convergence():
    print("Generating Fig 10: Convergence curves...")
    if not os.path.isdir(CURVES_DIR):
        print(f"  [SKIP] curves directory not found: {CURVES_DIR}")
        print("  Upload npy files to generate this figure.")
        return

    # Methods and datasets to show
    # MEL methods: curve_{V}_{DS}_run{N}.npy + nhd_{V}_{DS}_run{N}.npy
    # IGPSO/PSO_CSM: curve_{V}_{DS}_run{N}.npy only
    CONV_V    = ['FWPSO', 'MEL', 'MEL_NHD', 'MEL_KGEF_noNHD', 'PSO_CSM', 'IGPSO', 'MEL_KGEF']
    CONV_DS   = ['Adenoma', 'ALL_AML', 'Colon', 'DLBCL', 'Lymphoma', 'Stroke']  # 6 representative
    CONV_LBLS = [DS_LABELS[DATASETS.index(d)] for d in CONV_DS]

    fig, axes = plt.subplots(2, 3, figsize=(7.16, 4.4))
    axes = axes.ravel()

    for ax, ds, dslbl in zip(axes, CONV_DS, CONV_LBLS):
        for v in CONV_V:
            curves = []
            for run in range(10):
                fp = os.path.join(CURVES_DIR, f"curve_{v}_{ds}_run{run}.npy")
                if os.path.exists(fp):
                    c = np.load(fp)
                    curves.append(c)
            if not curves:
                continue
            curves  = np.array(curves)   # (n_runs, T+1)
            T       = curves.shape[1] - 1
            x_iter  = np.arange(T + 1)
            mean_c  = curves.mean(axis=0)
            std_c   = curves.std(axis=0)
            lw      = 1.4 if v == 'MEL_KGEF' else 0.8
            zo      = 10  if v == 'MEL_KGEF' else 2
            ls      = '-' if v == 'MEL_KGEF' else '--' if v in ['FWPSO','IGPSO'] else '-'
            ax.plot(x_iter, mean_c, color=COLORS[v], lw=lw,
                    linestyle=ls, zorder=zo, label=V_LABELS[v])
            ax.fill_between(x_iter, mean_c - std_c, mean_c + std_c,
                            color=COLORS[v], alpha=0.12, zorder=zo-1)

        ax.set_title(dslbl, fontsize=8, pad=2)
        ax.set_xlabel('Iteration', fontsize=7)
        ax.set_ylabel('Fitness', fontsize=7)
        ax.yaxis.set_major_formatter(mticker.FormatStrFormatter('%.3f'))
        ax.yaxis.set_major_locator(mticker.MaxNLocator(4))
        ax.grid(linestyle='--', alpha=0.4)

    handles = [mpatches.Patch(color=COLORS[v], label=V_LABELS[v]) for v in CONV_V]
    fig.legend(handles=handles, loc='lower center', ncol=4,
               bbox_to_anchor=(0.5, -0.04), frameon=True, fontsize=7,
               columnspacing=0.8)
    fig.tight_layout(rect=[0, 0.07, 1, 1])
    path = os.path.join(OUT_DIR, 'fig10_convergence.pdf')
    fig.savefig(path)
    fig.savefig(path.replace('.pdf','.png'))
    plt.close(fig)
    print(f"  Saved {path}")


# ═════════════════════════════════════════════════════════════════════════════
# Fig 11 — Radar / Spider Chart (overall performance profile, 5 metrics)
# ═════════════════════════════════════════════════════════════════════════════
def fig_radar():
    print("Generating Fig 11: Radar chart...")
    RADAR_V = ['FWPSO', 'MEL', 'MEL_NHD', 'MEL_KGEF_noNHD', 'PSO_CSM', 'IGPSO', 'MEL_KGEF']

    # 5 metrics (all normalized 0→1, higher=better)
    def metric_acc(v):
        return np.mean([get(v, ds).mean() for ds in DATASETS])
    def metric_feat(v):
        # Inverse normalised feature count (fewer = better)
        vals = np.array([get(v, ds, 'Num_Features').mean() for ds in DATASETS])
        all_max = max(get(vv, ds, 'Num_Features').mean()
                      for vv in RADAR_V for ds in DATASETS)
        return np.mean(1.0 - vals / all_max)
    def metric_stab(v):
        # Inverse std of accuracy (lower std = better)
        vals = np.array([get(v, ds).std() for ds in DATASETS])
        all_max = max(get(vv, ds).std() for vv in RADAR_V for ds in DATASETS)
        return np.mean(1.0 - vals / all_max)
    def metric_speed(v):
        vals = np.array([get(v, ds, 'Time_sec').mean() for ds in DATASETS])
        all_max = max(get(vv, ds, 'Time_sec').mean() for vv in RADAR_V for ds in DATASETS)
        return np.mean(1.0 - vals / all_max)
    def metric_nhd(v):
        nhd_vals = [get(v, ds, 'Avg_NHD').mean() for ds in DATASETS]
        valid = [x for x in nhd_vals if x > 0]
        if not valid: return 0.0
        all_max = max(get(vv, ds, 'Avg_NHD').mean()
                      for vv in RADAR_V for ds in DATASETS
                      if get(vv, ds, 'Avg_NHD').mean() > 0)
        return np.mean([x / all_max for x in valid])

    categories = ['Accuracy', 'Feature\nReduction', 'Stability', 'Speed', 'Diversity']
    N = len(categories)
    angles = np.linspace(0, 2 * np.pi, N, endpoint=False).tolist()
    angles += angles[:1]  # close polygon

    fig, ax = plt.subplots(figsize=(3.5, 3.5),
                           subplot_kw=dict(polar=True))

    for v in RADAR_V:
        scores = [metric_acc(v), metric_feat(v), metric_stab(v),
                  metric_speed(v), metric_nhd(v)]
        scores += scores[:1]
        lw   = 1.8 if v == 'MEL_KGEF' else 0.9
        ls   = '-' if v == 'MEL_KGEF' else '--'
        alph = 0.3 if v == 'MEL_KGEF' else 0.0
        ax.plot(angles, scores, color=COLORS[v], lw=lw, linestyle=ls,
                label=V_LABELS[v])
        ax.fill(angles, scores, color=COLORS[v], alpha=alph)

    ax.set_xticks(angles[:-1])
    ax.set_xticklabels(categories, fontsize=7.5)
    ax.set_yticklabels([])
    ax.set_ylim(0, 1)
    ax.grid(linewidth=0.5, linestyle='--', alpha=0.6)
    ax.spines['polar'].set_linewidth(0.6)

    ax.legend(loc='upper right', bbox_to_anchor=(1.35, 1.15),
              fontsize=6.5, frameon=True, ncol=1)

    fig.tight_layout()
    path = os.path.join(OUT_DIR, 'fig11_radar.pdf')
    fig.savefig(path)
    fig.savefig(path.replace('.pdf','.png'))
    plt.close(fig)
    print(f"  Saved {path}")


# ═════════════════════════════════════════════════════════════════════════════
# Main
# ═════════════════════════════════════════════════════════════════════════════
if __name__ == '__main__':
    print(f"Loaded {len(df)} rows  |  "
          f"{df['Version'].nunique()} versions  |  "
          f"{df['Dataset'].nunique()} datasets\n")

    fig_accuracy()
    fig_features()
    fig_ablation()
    fig_boxplot()
    fig_tradeoff()
    fig_rank()
    fig_nhd()
    fig_runtime()
    fig_wilcoxon_heatmap()
    fig_convergence()    # skipped if no npy files
    fig_radar()

    print(f"\nAll figures saved to ./{OUT_DIR}/")
    print("Files:")
    for f in sorted(os.listdir(OUT_DIR)):
        sz = os.path.getsize(os.path.join(OUT_DIR, f))
        print(f"  {f}  ({sz//1024} KB)")
